DerrpCore CoreLib fix
=====================

WHAT IT FIXES
CoreLib gives the Root Workbench a random internal ID every time the game starts. When your game
and the server roll different IDs, crafting the Root Workbench refunds your materials, and a few
nearby modded items (Ender Chest, Scarlet Chest, gems, pouches, saddles) can come out wrong.
This fix makes that ID the same on every PC, every launch. Everyone on DerrpCore needs it.

INSTALL (1 minute)
1. Close Core Keeper completely.
2. Unzip this folder anywhere (Desktop is fine).
3. Double-click Install-CoreLibFix.bat.
   If Windows says "Windows protected your PC", click "More info" then "Run anyway".
4. You should see FIXED (or "already fixed") next to each CoreLib folder it found.
5. Start Core Keeper and join DerrpCore.

WHEN TO RUN IT AGAIN
Whenever CoreLib gets an update on Steam, the update replaces the fixed file. Just run the .bat again.
If it ever says "NOT CHANGED: this CoreLib version looks different", tell NeoDerrp before playing.

UNDO
Open PowerShell in this folder and run:
  powershell -ExecutionPolicy Bypass -File Install-CoreLibFix.ps1 -Undo
(or unsubscribe and resubscribe to CoreLib on the Steam Workshop).

WHAT IT CHANGES
One line in CoreLib's Scripts\Entity\EntityModule.cs, in your Steam Workshop, mod.io and
game Mods-folder copies of CoreLib. The original is saved next to it as
EntityModule.cs.derrpcore-backup. Nothing else on your PC is touched. You can open the .ps1 in
Notepad to read exactly what it does.

DO IT BY HAND INSTEAD (optional)
Open: <Steam library>\steamapps\workshop\content\1621690\3673516180\Scripts\Entity\EntityModule.cs
Find this line:
    var authorBlock = API.DataBlocks.CreateRuntimeInstance<EntityAuthoringDataBlock>(CoreLibMod.modInfo.ModId);
Replace it with:
    var authorBlock = API.DataBlocks.CreateRuntimeInstance<EntityAuthoringDataBlock>(CoreLibMod.modInfo.ModId, new DataBlockAddress(new Guid(("CoreLib.RuntimeEntity:" + workbenchDefinition.itemID).GetGuid())));
Do the same in C:\Users\Public\mod.io\5289\mods\<CoreLib folder>\Scripts\Entity\EntityModule.cs if you have one.
