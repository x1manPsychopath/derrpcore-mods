<#
DerrpCore CoreLib fix
=====================
CoreLib gives the "Root Workbench" (and any workbench it builds at startup) a random internal ID
every time the game launches. When your game and the server roll different IDs, crafting the
Root Workbench refunds and a few nearby modded items (Ender Chest, Scarlet Chest, gems, pouches,
saddles...) get mixed up.

This script changes one line in CoreLib so that workbench gets the SAME ID on every PC, every launch.
It edits your existing CoreLib copies in place (Steam Workshop, mod.io, and the game's Mods folder),
keeps a backup next to the file, and changes nothing else.

  Install:   double-click Install-CoreLibFix.bat   (or: powershell -File Install-CoreLibFix.ps1)
  Undo:      powershell -ExecutionPolicy Bypass -File Install-CoreLibFix.ps1 -Undo
  Server:    powershell -File Install-CoreLibFix.ps1 -Path C:\GameServers\CoreKeeper\server-mods\3673516180

Re-run it after CoreLib gets a Steam update (the update replaces the fixed file).
#>
param(
    [string[]]$Path,
    [switch]$Undo,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$Marker = 'DERRPCORE-STABLE-ID-2'
$Target = 'var authorBlock = API.DataBlocks.CreateRuntimeInstance<EntityAuthoringDataBlock>(CoreLibMod.modInfo.ModId);'
$Fix = @(
    '            // DERRPCORE-STABLE-ID-2: fixed data-block address (built from the item name) so the object ID is identical on every PC and launch.',
    '            var authorBlock = API.DataBlocks.CreateRuntimeInstance<EntityAuthoringDataBlock>(CoreLibMod.modInfo.ModId, new DataBlockAddress(new Guid(("CoreLib.RuntimeEntity:" + workbenchDefinition.itemID).GetGuid())));'
)

function Say($msg, $color = 'Gray') { if (-not $Quiet) { Write-Host $msg -ForegroundColor $color } }

function Get-CoreLibFolders {
    $found = New-Object System.Collections.Generic.List[string]
    # Steam libraries
    $steam = $null
    foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam') {
        try { $p = Get-ItemProperty $key -ErrorAction Stop; $steam = if ($p.SteamPath) { $p.SteamPath } else { $p.InstallPath }; if ($steam) { break } } catch {}
    }
    $libraries = @()
    if ($steam) {
        $steam = $steam -replace '/', '\'
        $libraries += $steam
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) { $libraries += ($m.Groups[1].Value -replace '\\\\', '\') }
        }
    }
    foreach ($lib in ($libraries | Select-Object -Unique)) {
        $ws = Join-Path $lib 'steamapps\workshop\content\1621690'
        if (Test-Path $ws) { Get-ChildItem $ws -Directory | ForEach-Object { $found.Add($_.FullName) } }
        $local = Join-Path $lib 'steamapps\common\Core Keeper\CoreKeeper_Data\StreamingAssets\Mods'
        if (Test-Path $local) { Get-ChildItem $local -Directory | ForEach-Object { $found.Add($_.FullName) } }
    }
    # mod.io
    $modio = Join-Path $env:PUBLIC 'mod.io\5289\mods'
    if (Test-Path $modio) { Get-ChildItem $modio -Directory | ForEach-Object { $found.Add($_.FullName) } }
    # keep only CoreLib folders
    $found | Where-Object {
        $manifest = Join-Path $_ 'ModManifest.json'
        (Test-Path $manifest) -and ((Get-Content $manifest -Raw) -match '"name"\s*:\s*"CoreLib"')
    } | Select-Object -Unique
}

function Read-Text($file) {
    $bytes = [IO.File]::ReadAllBytes($file)
    $bom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    $text = [Text.Encoding]::UTF8.GetString($bytes, $(if ($bom) { 3 } else { 0 }), $bytes.Length - $(if ($bom) { 3 } else { 0 }))
    return @{ Text = $text; Bom = $bom }
}

function Write-Text($file, $text, $bom) {
    [IO.File]::WriteAllText($file, $text, (New-Object Text.UTF8Encoding($bom)))
}

$folders = if ($Path) { $Path } else { @(Get-CoreLibFolders) }
if (-not $folders -or $folders.Count -eq 0) {
    Say 'No CoreLib found. Subscribe to CoreLib on the Steam Workshop, launch Core Keeper once, then run this again.' Yellow
    exit 1
}

$results = @()
foreach ($folder in $folders) {
    $file = Join-Path $folder 'Scripts\Entity\EntityModule.cs'
    $backup = "$file.derrpcore-backup"
    if (-not (Test-Path $file)) { $results += [pscustomobject]@{ Folder = $folder; Result = 'skipped (no EntityModule.cs)' }; continue }
    $c = Read-Text $file
    if ($Undo) {
        if (Test-Path $backup) { Copy-Item $backup $file -Force; Remove-Item $backup; $results += [pscustomobject]@{ Folder = $folder; Result = 'restored original' } }
        else { $results += [pscustomobject]@{ Folder = $folder; Result = 'nothing to undo' } }
        continue
    }
    if ($c.Text.Contains($Marker)) { $results += [pscustomobject]@{ Folder = $folder; Result = 'already fixed' }; continue }
    $idx = $c.Text.IndexOf($Target)
    if ($idx -lt 0) { $results += [pscustomobject]@{ Folder = $folder; Result = 'NOT CHANGED: this CoreLib version looks different (it may already include a fix)' }; continue }
    $nl = if ($c.Text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $lineStart = $c.Text.LastIndexOf("`n", $idx) + 1
    $lineEnd = $c.Text.IndexOf("`n", $idx)
    $after = if ($lineEnd -ge 0) { $c.Text.Substring($lineEnd + 1) } else { '' }
    $newText = $c.Text.Substring(0, $lineStart) + ($Fix -join $nl) + $nl + $after
    Copy-Item $file $backup -Force
    Write-Text $file $newText $c.Bom
    $results += [pscustomobject]@{ Folder = $folder; Result = 'FIXED' }
}

if (-not $Quiet) { $results | Format-Table -AutoSize -Wrap | Out-String | Write-Host }
if ($results | Where-Object { $_.Result -like 'FIXED' -or $_.Result -eq 'already fixed' -or $_.Result -eq 'restored original' }) {
    Say $(if ($Undo) { 'Done. Restart Core Keeper to go back to the original CoreLib.' } else { 'Done. Restart Core Keeper (fully close it first) for the fix to take effect.' }) Green
    exit 0
}
exit 1
