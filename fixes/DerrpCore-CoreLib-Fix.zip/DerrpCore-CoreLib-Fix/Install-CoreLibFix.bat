@echo off
title DerrpCore CoreLib fix
echo Close Core Keeper before continuing.
pause
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-CoreLibFix.ps1"
echo.
pause
